package com.example.adipermana;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.leo.simplearcloader.SimpleArcLoader;

import org.eazegraph.lib.charts.PieChart;
import org.eazegraph.lib.models.PieModel;
import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {
    TextView tvKasus, tvSembuh,tvRawat, tvAktif, tvKasushari,tvTotalkematian, tvKematianHari,tvJumlahNegara;
    SimpleArcLoader simpleArcLoader;
    ScrollView scrollView;
    PieChart pieChart;

    @Override
    protected void onCreate(Bundle savedInstanceState) { super.onCreate(savedInstanceState); setContentView(R.layout.activity_main);

        tvKasus = findViewById(R.id.tvKasus);
        tvSembuh = findViewById(R.id.tvSembuh);
        tvRawat = findViewById(R.id.tvRawat);
        tvAktif = findViewById(R.id.tvAktif);
        tvKasushari = findViewById(R.id.tvHari);
        tvTotalkematian =findViewById(R.id.tvTmeninggal);
        tvKematianHari = findViewById(R.id.tvMati);
        tvJumlahNegara = findViewById(R.id.tvJumlah);
        simpleArcLoader = findViewById(R.id.loader);
        scrollView = findViewById(R.id.scrollStats);
        pieChart = findViewById(R.id.piechart);

        fetchData();

    }

    private void fetchData() {
        String url = "https://corona.lmao.ninja/v2/all/";

        simpleArcLoader.start();
        StringRequest request = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                try {
                    JSONObject jsonObject = new JSONObject(response.toString());
                    tvKasus.setText(jsonObject.getString("cases"));
                    tvSembuh.setText(jsonObject.getString("recovered"));
                    tvRawat.setText(jsonObject.getString("critical"));
                    tvAktif.setText(jsonObject.getString("active"));

                    tvKasushari.setText(jsonObject.getString("todayCases")); tvTotalkematian.setText(jsonObject.getString("deaths")); tvKematianHari.setText(jsonObject.getString("todayDeaths")); tvJumlahNegara.setText(jsonObject.getString("affectedCountries"));
                    pieChart.addPieSlice(new PieModel("Cases",Integer.parseInt(tvKasus.getText().toString()), Color.parseColor("#FFA726")));
                    pieChart.addPieSlice(new PieModel("Recoverd",Integer.parseInt(tvSembuh.getText().toString()), Color.parseColor("#66BB6A")));
                    pieChart.addPieSlice(new PieModel("Deaths",Integer.parseInt(tvTotalkematian.getText().toString()), Color.parseColor("#EF5350")));
                    pieChart.addPieSlice(new PieModel("Active",Integer.parseInt(tvAktif.getText().toString()), Color.parseColor("#29B6F6")));
                    pieChart.startAnimation();

                    simpleArcLoader.stop(); simpleArcLoader.setVisibility(View.GONE); scrollView.setVisibility(View.VISIBLE);


                } catch (JSONException e) { e.printStackTrace(); simpleArcLoader.stop(); simpleArcLoader.setVisibility(View.GONE); scrollView.setVisibility(View.VISIBLE);
                }

            }
        }, new Response.ErrorListener() { @Override
        public void onErrorResponse(VolleyError error) { simpleArcLoader.stop(); simpleArcLoader.setVisibility(View.GONE);

            scrollView.setVisibility(View.VISIBLE);

            Toast.makeText(MainActivity.this,error.getMessage(),Toast.LENGTH_SHORT).show(
            );
        }
        });
        RequestQueue requestQueue = Volley.newRequestQueue(this); requestQueue.add(request);

    }
    public void goCari(View view) { startActivity(new
            Intent(getApplicationContext(), AffectedCountries.class));
    }
}

